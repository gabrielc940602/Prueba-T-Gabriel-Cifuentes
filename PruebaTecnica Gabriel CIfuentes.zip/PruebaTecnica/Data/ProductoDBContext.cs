﻿using Microsoft.EntityFrameworkCore;
using PruebaTecnica.Models;

namespace PruebaTecnica.Data
{
    public class ProductoDBContext: DbContext
    {
        public ProductoDBContext(DbContextOptions<ProductoDBContext> options): base(options)
        {
            
        }
       protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            base.OnModelCreating(modelBuilder);
        }
        public DbSet<Atributo> Atributo { get; set; }
        public DbSet<AtributoCategoria> AtributoCategoria { get; set; }
        public DbSet<AtributoSubCategoria> AtributoSubCategoria { get; set; }
        public DbSet<Categoria> Categoria { get; set; }
        public DbSet<Producto> Producto { get; set; }
        public DbSet<ProductoAtributo> ProductoAtributo { get; set; }
        public DbSet<SubCategoria> SubCategoria { get; set; }
    }
}
