﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PruebaTecnica.Data;
using PruebaTecnica.DTO;
using PruebaTecnica.Helpers;

namespace PruebaTecnica.Controllers
{
    [ApiController]
    [Route("api/productos")]
    public class ProductoController: ControllerBase
    {
        private readonly ProductoDBContext context;
        private readonly IMapper mapper;

        public ProductoController(ProductoDBContext context, IMapper mapper)
        {
            this.context = context;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<ActionResult<List<ProductoDTO>>> GetProductos([FromQuery] PaginacionDTO paginacion, string nombre)
        {
            var queryable = context.Producto.Include(x => x.Categoria).ThenInclude(x => x.SubCategoria).AsQueryable();
            await HttpContext.InsertarparametrosEnCabecera(queryable);
            var productos = await queryable.Where(x => x.Categoria.Nombre == nombre || x.SubCategoria.Nombre == nombre).ToListAsync();
            return mapper.Map<List<ProductoDTO>>(productos);
        }
    }
}
