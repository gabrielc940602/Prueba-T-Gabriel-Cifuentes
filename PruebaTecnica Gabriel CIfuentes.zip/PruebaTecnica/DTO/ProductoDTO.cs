﻿using PruebaTecnica.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace PruebaTecnica.DTO
{
    public class ProductoDTO
    {
        
        public string SKU { get; set; }
        public string MPN { get; set; }
        public string Nombre { get; set; }
        
    }
}
