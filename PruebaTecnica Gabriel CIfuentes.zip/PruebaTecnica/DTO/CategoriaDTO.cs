﻿using PruebaTecnica.Models;

namespace PruebaTecnica.DTO
{
    public class CategoriaDTO: EntityBaseDTO
    {
        public string Nombre { get; set; }
        public List<SubCategoria> SubCategoria { get; set; }
        public List<AtributoCategoria> AtributoCategoria { get; set; }
    }
}
