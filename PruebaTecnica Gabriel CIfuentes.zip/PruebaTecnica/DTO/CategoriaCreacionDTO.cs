﻿using PruebaTecnica.Models;

namespace PruebaTecnica.DTO
{
    public class CategoriaCreacionDTO
    {
        public string Nombre { get; set; }
        public List<SubCategoria> SubCategoria { get; set; }
        public List<AtributoCategoria> AtributoCategoria { get; set; }
    }
}
