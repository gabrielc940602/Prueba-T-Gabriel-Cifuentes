﻿namespace PruebaTecnica.DTO
{
    public class EntityBaseDTO
    {
        public Guid Id { get; set; }
    }
}
