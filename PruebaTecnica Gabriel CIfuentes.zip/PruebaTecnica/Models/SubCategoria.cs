﻿using System.ComponentModel.DataAnnotations.Schema;

namespace PruebaTecnica.Models
{
    public class SubCategoria: EntityBase
    {
        public string Nombre { get; set; }
        [ForeignKey(nameof(Categoria))]
        public Guid CategoriaId { get; set; }
        public Categoria Categoria { get; set;}
    }
}
