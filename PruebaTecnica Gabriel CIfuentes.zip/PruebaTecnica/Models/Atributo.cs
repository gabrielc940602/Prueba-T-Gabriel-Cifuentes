﻿namespace PruebaTecnica.Models
{
    public class Atributo: EntityBase
    {
        public string Nombre { get; set; }
        public List<ProductoAtributo> ProductoAtributo { get; set; }
        public List<AtributoCategoria> AtributoCategoria { get; set; }
    }
}
