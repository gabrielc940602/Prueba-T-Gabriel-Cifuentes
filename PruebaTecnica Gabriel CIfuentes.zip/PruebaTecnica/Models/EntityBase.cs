﻿using Microsoft.EntityFrameworkCore;

namespace PruebaTecnica.Models
{
    public class EntityBase
    {
        
        public Guid Id { get; set; }
    }
}
