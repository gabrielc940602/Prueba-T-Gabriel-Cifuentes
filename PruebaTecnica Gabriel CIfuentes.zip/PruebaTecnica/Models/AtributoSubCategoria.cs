﻿using System.ComponentModel.DataAnnotations.Schema;

namespace PruebaTecnica.Models
{
    public class AtributoSubCategoria
    {
        [ForeignKey(nameof(Atributo))]
        public Guid AtributoId { get; set; }
        public Atributo Atributo { get; set; }
        [ForeignKey(nameof(Categoria))]
        public Guid SubCategoriaId { get; set; }
        public SubCategoria SubCategoria { get; set; }
    }
}
