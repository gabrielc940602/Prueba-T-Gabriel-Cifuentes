﻿using System.ComponentModel.DataAnnotations.Schema;

namespace PruebaTecnica.Models
{
    public class AtributoCategoria:EntityBase
    {
        [ForeignKey(nameof(Atributo))]
        public Guid AtributoId { get; set; }
        public Atributo Atributo { get; set; }
        [ForeignKey(nameof(Categoria))]
        public Guid CategoriaId { get; set; }
        public Categoria Categoria { get; set;}
    }
}
