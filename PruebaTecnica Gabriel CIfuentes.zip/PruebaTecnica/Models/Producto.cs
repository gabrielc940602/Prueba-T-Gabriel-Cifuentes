﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PruebaTecnica.Models
{
    public class Producto
    {
        [Required]
        [Key]
        public string SKU { get; set; }
        public string MPN { get; set; }
        public string Nombre { get; set; }
        [ForeignKey(nameof(Categoria))]
        public Guid CategoriaId { get; set; }
        public Categoria Categoria { get; set;}
        [ForeignKey(nameof(SubCategoria))]
        public Guid SubCategoriaId { get; set; }
        public SubCategoria SubCategoria { get; set; }
        public List<ProductoAtributo> ProductoAtributo { get; set; }
    }
}
