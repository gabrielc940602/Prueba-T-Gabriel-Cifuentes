﻿namespace PruebaTecnica.Models
{
    public class Categoria: EntityBase
    {
        public string Nombre { get; set; }
        public List<SubCategoria> SubCategoria { get; set; }
        public List<AtributoCategoria> AtributoCategoria { get; set; }
    }
}
