﻿using System.ComponentModel.DataAnnotations.Schema;

namespace PruebaTecnica.Models
{
    public class ProductoAtributo:EntityBase
    {
        [ForeignKey(nameof(Producto))]
        public string ProductoSKU { get; set; }
        public Producto Producto { get; set; }
        [ForeignKey(nameof(Atributo))]
        public Guid AtributoId { get; set; }
        public Atributo Atributo { get; set; }
        public string Valor { get; set; }
    }
}
