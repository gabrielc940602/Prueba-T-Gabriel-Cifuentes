﻿using AutoMapper;
using PruebaTecnica.DTO;
using PruebaTecnica.Models;

namespace PruebaTecnica.Mapper
{
    public class AutoMapperProfiles: Profile
    {
        public AutoMapperProfiles()
        {
            
            CreateMap<Producto,ProductoDTO>().ReverseMap();
        }
    }
}
